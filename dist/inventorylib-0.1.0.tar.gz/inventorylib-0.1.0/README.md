# Inventory Management Library

A Python library to calculate:

- Economic Order Quantity (EOQ)
- Reorder Point (ROP)
- Safety Stock
- Total Inventory Cost
- EOQ with Bulk Discount

Includes a CLI script for easy usage.
